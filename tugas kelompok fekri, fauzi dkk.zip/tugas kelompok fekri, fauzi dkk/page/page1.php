<center><h2>BIODATA SAYA</h2>
<table width='600' height='300' border='5'  cellpadding="6" cellspacing="0">
    <tr>
    
        <td width='200' height='5'>Nama Lengkap</td>
        <td width='500'>Muhammad ikhwan fauzi</td>
    </tr>
    <tr>

        <td width='200' height='10'>Npm</td>
        <td>2055201134</td>
    </tr>
    <tr>

        <td>Nama Panggilan</td>
        <td>Fauzi</td>
    <tr>

        <td>Alamat</td>
        <td>Kadang Mas,Kampung Melayu</td>
    </tr>
    <tr>

        <td>Email</td>
        <td>muhammadikhwandesu@gmail.com</td>
    </tr>
    <tr>

        <td>Nomor HP</td>
        <td>085898769574</td>
	</tr>
	<tr>
        <td><img src="img/a.jpeg" width="180px;" height="240px;" border="5"></td>
        <td><center>Teruslah Berjuang !!<br> Walaupun Itu Berat!!</td>
    </tr>
</table>
