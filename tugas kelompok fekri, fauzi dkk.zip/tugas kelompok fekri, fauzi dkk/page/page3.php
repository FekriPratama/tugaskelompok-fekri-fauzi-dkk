<center><h2>BIODATA SAYA</h2>
<table width='600' height='300' border='5'  cellpadding="6" cellspacing="0">
    <tr>
    
        <td width='200' height='5'>Nama Lengkap</td>
        <td width='500'>Khairul Razikin </td>
    </tr>
    <tr>

        <td width='200' height='10'>Npm</td>
        <td>205520103</td>
    </tr>
    <tr>

        <td>Nama Panggilan</td>
        <td>Khairul</td>
    <tr>

        <td>Alamat</td>
        <td>Jalan Sentot Alibasyah </td>
    </tr>
    <tr>

        <td>Email</td>
        <td>mkhairulrazikin24@gmail.com</td>
    </tr>
    <tr>

        <td>Nomor HP</td>
        <td>083182451166</td>
	</tr>
	<tr>
        <td><img src="img/k.jpg" width="180px;" height="240px;" border="5"></td>
    </tr>
</table>
